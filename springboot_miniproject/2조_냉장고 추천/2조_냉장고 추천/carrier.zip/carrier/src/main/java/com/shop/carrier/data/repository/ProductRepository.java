// package com.shop.carrier.data.repository;

// import org.springframework.data.jpa.repository.JpaRepository;
// import com.shop.carrier.data.entity.Product;

// public interface ProductRepository extends JpaRepository<Product, Long> {
// // 사용자 정의 쿼리 메서드 등을 정의 가능
// }
