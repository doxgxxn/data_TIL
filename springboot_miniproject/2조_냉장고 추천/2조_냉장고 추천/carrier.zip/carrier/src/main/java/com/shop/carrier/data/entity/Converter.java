// package com.shop.carrier.data.entity;

// import org.springframework.stereotype.Component;

// @Component
// public class Converter implements Converter<Carrier, ResponseDto> {

// @Override
// public ResponseDto convert(Carrier carrier) {
// ResponseDto responseDto = new ResponseDto();
// // Perform conversion logic here
// // Map properties from Carrier to ResponseDto
// responseDto.setId(carrier.getId());
// responseDto.setName(carrier.getName());
// // ... and so on

// return responseDto;
// }
// }
